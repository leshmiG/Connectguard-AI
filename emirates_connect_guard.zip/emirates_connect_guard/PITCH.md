# Pitching ConnectGuard to Emirates

## The narrative, in five beats

**1. The problem (their words, not yours)**
Emirates' entire business model runs on Dubai as a super-connector hub. <cite>Small upstream delays on long-haul routes cascade into missed connections</cite> — and 2026 has stress-tested this repeatedly: <cite>winter storms and airspace closures triggered waves of delays and cancellations across the network</cite>, with a single day in August 2026 seeing <cite>490 delays across Middle East air corridors</cite>.

**2. The gap (specific, not generic)**
<cite>Emirates has already invested in AI for turbulence prediction, flight planning, aircraft reliability, and lounge-volume forecasting three days out</cite> — a real, sophisticated program. Passenger connection-risk prediction isn't in that list. That's the gap, and it's precise enough to sound like you did the homework, not like a generic "AI could help airlines" pitch.

**3. The solution (show, don't just tell)**
A working prototype — not a slide, a deployed link — that reads live flight status and hub weather, scores missed-connection risk with reasoning (not just a threshold), and proactively drafts rebooking options, with human sign-off before anything actually changes. Walk them through the architecture diagram in under two minutes.

**4. The proof**
You didn't just build it, you verified it: correctly differentiated a high-risk itinerary from a low-risk one in the same run, correctly gated the rebooking action behind approval, correctly isolated one runaway itinerary so it didn't take down the rest of the batch — and you found and fixed a real bug during that testing (the batch-crash issue), which is a better interview story than a clean first try would have been.

**5. The ask**
Not "invest in this." Something small and specific: 15 minutes to walk someone through it, or feedback on whether the risk-scoring approach matches how their Network Control Centre actually reasons about connection risk today.

---

## Where to actually send it

### If you're already in their hiring pipeline (you are — Analytics & Insights Specialist)
This is your strongest and most direct channel. Reference the live prototype **in your application and at interview**, not as an attachment buried in a portfolio link — say explicitly: "I noticed connection-risk prediction wasn't among your public AI initiatives, so I built a working prototype to show the approach." A recruiter or hiring manager sees dozens of "I'm passionate about AI" applications; almost none show up with a deployed, tested system addressing a gap they can independently verify is real.

### Intelak — Emirates Group's startup incubator/accelerator
Built with Amadeus, Microsoft, Accenture, and Dubai's Department of Economy and Tourism, specifically to <cite>identify and support start-ups in the travel, tourism, and aviation sectors, providing mentorship, resources, and funding</cite>. You're not raising funding, but Intelak's application process is the most structured, lowest-friction path to getting an internal team to actually look at unsolicited aviation-tech ideas — worth applying even as an individual with a working prototype rather than a registered startup; many accelerators of this type will still take a meeting off the back of a strong demo.

### Aviation X Lab
A partnership between <cite>Emirates Group, Collins Aerospace, Thales, and Airbus</cite>, focused specifically on aviation technology innovation. More industry-technical than Intelak's broader travel/tourism focus — a better fit if the pitch leans hard on the operational/Network Control Centre angle rather than the passenger-experience angle.

### ForsaTEK
Emirates Group's <cite>annual innovation platform, bringing together technology partnerships, the start-up ecosystem, and new concepts and ideas</cite>, opened by Emirates' own Chairman. This is an event, not a standing application channel — worth watching for the next edition's call for demos/exhibitors (the "Start-up Souk" format has featured 20+ startups pitching directly to VIPs and industry leaders in past editions).

### The Emirates-OpenAI AI Centre of Excellence angle
<cite>Emirates and OpenAI are jointly building an internal AI champion network and a dedicated AI Centre of Excellence</cite>, explicitly designed to <cite>identify key areas for enhancing AI capabilities</cite> and <cite>enable rapid prototyping in crew management, fleet operations, planning, and customer engagement</cite>. This tells you two things: (1) there's very likely an internal team actively looking for exactly this kind of use case right now, and (2) "planning" is explicitly named as a target area — connection-risk prediction sits squarely inside it. Worth a direct, short LinkedIn message to whoever's driving that initiative (Ali Serdar Yakut, EVP IT, is publicly named in coverage of Emirates' digital transformation work) — reference the specific initiative by name, attach the deployed link, keep it to three sentences.

### What not to do
Don't cold-email a generic "info@emirates.com" address — it won't reach anyone who can act on it. Don't lead with "I built an AI agent" as the headline — lead with the specific operational gap, backed by their own public statements, with the working system as the proof, not the pitch itself.

---

## The one-paragraph version, if you only get one message

> "Emirates' hub model depends on tight Dubai connections, and 2026's airspace disruptions have made missed-connection risk a live operational problem. I noticed connection-risk prediction isn't among your publicly listed AI initiatives (turbulence, flight planning, lounge forecasting), so I built and tested a working prototype that predicts missed-connection risk from live flight/weather data and proactively drafts rebooking options, gated behind human approval. It's deployed here: [link]. Happy to walk through the architecture if useful."
